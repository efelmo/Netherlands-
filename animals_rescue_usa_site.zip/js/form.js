document.getElementById('volunteerForm').addEventListener('submit',function(e){
e.preventDefault();document.getElementById('statusMessage').classList.remove('hidden');
document.getElementById('statusMessage').innerText="Application submitted successfully!";});